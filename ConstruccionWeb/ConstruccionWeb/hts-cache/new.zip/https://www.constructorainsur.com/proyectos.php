<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>INSUR - constructora</title><link rel="shortcut icon" href="images/favicon.png"><meta name="description" content="Especialistas en las construcción de Naves y Obras Industriales" /><meta name="keywords" content="Construcción  de naves industriales, Construcción  de naves industriales Bajio, Construcción de naves industriales mexico, Construcción de naves industriales queretaro, Construcción de naves industriales san Luis potosi, Construcción industrial, Construcción industrial bajio, Construcción industrial mexico, Construcción industrial Queretaro, Construcción industrial San Luis potosi, Naves industriales, Naves industriales bajio, Naves industriales  Mexico, Naves industriales Queretaro, Naves industriales  San Luis potosi, Construcción obra civil, Construcción estructura metálica, Arquitectura industrial, Construcción de bodegas, Construcción de almacenes, Construcción de plantas de produccion, Construcción de cuartos limpios, Construcción alimenticia, Construcción farmacéutica, Construcción cimentaciones especiales"/><link href="css/boilerplate.css" rel="stylesheet" type="text/css" media="all"><link href="css/estilos.min.css" rel="stylesheet" type="text/css" media="all"><link href="https://fonts.googleapis.com/css?family=Roboto:400,900" rel="stylesheet">

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script async src="js/respond.min.js"></script><link href="css/owl.carousel.css" rel="stylesheet"><link href="css/owl.theme.css" rel="stylesheet"><link href="css/owl.transitions.css" rel="stylesheet"><link async href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">  <script src="assets/js/jquery-1.9.1.min.js"></script> <script src="js/owl.carousel.js"></script><style>#owl-demo .item img, #owl-demo_interna .item img, #owl-demo2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){var a=$("#owl-demo");a.owlCarousel({navigation:!1,singleItem:!0,transitionStyle:"fade",autoPlay:7e3}),$("#transitionType").change(function(){var t=$(this).val();a.data("owlCarousel").transitionTypes(t),a.trigger("owl.next")})});</script><script src='https://www.google.com/recaptcha/api.js'></script>	<style>#owl-demo_2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){$("#owl-demo_2").owlCarousel({navigation:!1,slideSpeed:300,singleItem:!0,autoPlay:!0,lazyLoad:!0})});</script><script type="text/javascript">$(document).on("scroll",function(){$(document).scrollTop()>360?($("#submenu").addClass("fijo"),$("#w_gale_proy").addClass("espacio")):($("#submenu").removeClass("fijo"),$("#w_gale_proy").removeClass("espacio"))}),$(document).ready(function(){$("#cerrar").click(function(){$("#example2_pop").hasClass("quitar")?($("#example2_pop").removeClass("quitar"),$("#cerrar").removeClass("girar")):($("#example2_pop").addClass("quitar"),$("#example2_pop_").addClass("quitar"),$("#cerrar").addClass("girar"))})}),$(document).ready(function(){$("#chat").click(function(){$("#example2_pop").hasClass("ver")?$("#example2_pop").removeClass("ver"):($("#example2_pop").addClass("ver"),$("#example2_pop_").addClass("ver"))})});</script><script>$(function(t){t("#submenu a").click(function(){var n=t(this).attr("href"),a=t(n).offset().top;return t("html:not(:animated),body:not(:animated)").animate({scrollTop:a},400),!1})});</script><script>function validar_contacto(){var e=document.getElementById("nombre").value,t=document.getElementById("email").value,n=document.getElementById("comentario").value;return 0==e.length?(alert("Ingresa tu nombre"),nombre.focus(),!1):0==t.length?(alert("Ingresa un correo electrónico"),email.focus(),!1):0==n.length?(alert("Dejanos tus comentarios"),comentario.focus(),!1):void 0}</script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-45144045-1"></script>
  
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 
  gtag('config', 'UA-45144045-1');
</script>
</head><body>
    
    <ul class="navigation">
  <li> <a href="index.php" class="transition" >HOME</a> </li>
                    <li> <a href="conocenos.php" class="transition" >CONÓCENOS</a> </li>
                    <li> <a href="servicios.php" class="transition" >SERVICIOS</a> </li>
                    <li> <a href="proyectos.php" class="activo transition" >PROYECTOS</a> </li>
                    <li> <a href="clientes.php" class="transition" >CLIENTES</a> </li>
                    <li> <a href="contacto.php" class="transition" >CONTACTO</a> </li>
                    <li> <li> <a href="ing/proyectos.php">ENG</a> </li> </li>

  <li><a href="mailto:info@constructorainsur.com">info@constructorainsur.com<br />(442) 215 3019</a></li>
</ul>
<input type="checkbox" id="nav-trigger" class="nav-trigger" />
<label for="nav-trigger"></label>
    <div class="site-wrap">
    <div id="logo_ip"><img class="logo" src="images/logo_menu.jpg" width="48%"/></div>

<div id="w_menu">
        <div class="gridContainer clearfix">
        	<div id="logo_menu"> <a href="index.php"><img src="images/logo_menu.jpg"></a> </div>
            <div id="menu">
            	<ul>
                	<li> <a href="index.php" class="transition" >home</a> </li>
                    <li> <a href="conocenos.php" class="transition" >conócenos</a> </li>
                    <li> <a href="servicios.php" class="transition" >servicios</a> </li>
                    <li> <a href="proyectos.php" class="activo transition" >proyectos</a> </li>
                    <li> <a href="clientes.php" class="transition" >clientes</a> </li>
                    <li> <a href="contacto.php" class="transition" >contacto</a> </li>
                    
                    <li> <a href="ing/proyectos.php"><img src="images/idioma.png"> ENG</a> </li>                    
                </ul>
            </div>
            <div class="cleare"></div>
        
        </div>
    </div>
        
    <div id="top">
    	        <div id="redes"> 
        	<div id="face" class="redes_flotante"> <a href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"> <img src="images/face.png"></a> </div>
            <div id="idioma" class="redes_flotante"> <a href="#"><img src="images/idioma.png"> ENG</a></div>
        	<div class="cleare"></div>
        </div>        
        <div id="slide_internas" style=" background: url(images/slide_proy.jpg) center / cover">
        	<div class="caption">ALTA CALIDAD <br><!--<hr style=" width: 30px; text-align: center">--><span>EN CONSTRUCCIÓN</span></div>
        </div>
    </div>
    
     <div id="submenu">
    	<div class="gridContainer clearfix">
        	<ul id="menu_proy">
                <li> <a href="proyectos.php#w_menu" class="activo transition btn_en_proy">CONCLUIDOS</a></li>
                <li> <a href="proyectos.php?tipo=proceso#w_menu" class="btn_en_proy transition">EN PROCESO</a></li>
                <!--<li> <a href="proyectos_pro.php#w_menu" >EN PROCESO</a></li>-->
            </ul>
        </div>
    </div>
    
<div id="submenu" class="mostrar_ip">
    	<div class="gridContainer clearfix">
        	<ul id="menu_proy">
                <li> <a href="proyectos.php#w_menu" class="activo transition btn_en_proy">CONCLUIDOS</a></li>
                <li> <a href="proyectos.php?tipo=proceso#w_menu" class="btn_en_proy transition">EN PROCESO</a></li>
                <!--<li> <a href="proyectos_pro.php#w_menu" >EN PROCESO</a></li>-->
            </ul>
        </div>
    </div>
        
    <div id="w_gale_proy">
    	<br><br>
    	<h1 class="titulo" style=" text-align: center;">PROYECTOS CONCLUIDOS</h1><br><br>
        <div id="thumb">
        	<div class="gridContainer clearfix">
            <h1 class="titulo" style=" font-size: 20px">Farmacéutico</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=4" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Nucitec</div><div class="fecha"> 2014 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/DSC_0184.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=27" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/alemania.png"> B.Braun</div><div class="fecha"> 2018 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/BBRAUN_01.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Herramientas</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=1" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Truper</div><div class="fecha"> 2012 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/truper.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Automotriz</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=6" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/canada.png"> Narmx</div><div class="fecha"> 2016 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/NARMX-1.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=8" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/china.png"> Aceway</div><div class="fecha"> 2015 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/IMG_0821.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=15" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/alemania.png"> Ronal</div><div class="fecha"> 2015 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/ronal.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=17" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> Bandag</div><div class="fecha"> 2000 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/DSC_0002B.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=19" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/alemania.png"> Kirchhoff</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/3.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=24" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> STEMCO</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/20621009_1390925104305873_5026135068493042289_n.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Alimenticio</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=5" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Canels</div><div class="fecha"> 2016 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/IMG_9919.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Cartón y Papel</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=9" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> International Paper Nuevo León</div><div class="fecha"> 2001 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/DSC00178.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=10" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> International Paper Guanajuato</div><div class="fecha"> 1997 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/INLAND_GTO_1.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=22" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> Graphic Packaging</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/gSVN1H-a.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Plástico</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=11" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Plastienvases</div><div class="fecha"> 1995 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/Plastienvases.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=12" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/italia.png"> Irritec</div><div class="fecha"> 2014 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/IMG_1741.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=20" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> Rubbermaid</div><div class="fecha"> 1996 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/rubbermaid.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=29" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/japon.png"> YAMADA </div><div class="fecha"> 2018 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/C-02.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Químico</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=13" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/suiza.JPG"> Sika</div><div class="fecha"> 2010 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/Q-60.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=25" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/italia.png"> MAPEI</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/MAPEI-4.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Aeroespacial</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=21" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Mexicana MRO</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/MEXICANA-1.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=28" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/bandera reino unido.png"> ITP AERO</div><div class="fecha"> 2018 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/1.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Metalmecánico</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=14" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> Peco Facet</div><div class="fecha"> 2013 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/pecofacet.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=23" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/italia.png"> Élica</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/ACCESO.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=34" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> FANASA</div><div class="fecha"> 2019 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/2.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Logístico</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=18" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Asimex Global</div><div class="fecha"> 2014 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/asimex.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Textil</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=7" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/brasil.png"> Fitesa</div><div class="fecha"> 2015 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/F003.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Cosméticos</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=16" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/estados unidos.png"> Revlon</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/REVLON-3.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div><h1 class="titulo" style=" font-size: 20px">Agropecuario</h1><br><div class="thumb_flotante"><a href="detalle.php?tipo=concluidos&proyecto=26" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> AGRO ALPINA</div><div class="fecha"> 2017 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/Agroalpina_1.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="cleare"></div>            </div>
        </div>
    </div>
    <div id="w_footer" style="letter-spacing:1px">
    	<div class="gridContainer clearfix">
        	<div id="logo_ft"> <img src="images/logo_ft.png"> <p>®2020, DERECHOS RESERVADOS</p> </div>
            <div id="redes_ft"> <p>Tel. (442) 215 3019 /</p>
            <a href="mailto:info@constructorainsur.com" style=" color: #fff">info@constructorainsur.com</a>
            <a id="fbfull" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fbfull" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fbfull" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fbfull" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
            </div>
            <a id="fb" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fb" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fb" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fb" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
        	<div class="cleare"></div>
        </div>
    </div>

<!--fin de responsive-->
</div>
<div class="quitar--caca">

    <link rel="stylesheet" href="css/flickity.css" media="screen">
    <script src="js/flickity.pkgd.js"></script>
    <script src="js/flickity-docs.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.main-carousel').flickity({
                // options
                cellAlign: 'left',
                groupCells: 3,
                imagesLoaded: true,
                pageDots: false,
                autoPlay: 6000,
            });
        });
    </script>
</div>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
		(function () {
		var options = {
		whatsapp: "+524423150697", // WhatsApp number
		call_to_action: "Escríbenos", // Call to action
		position: "right", // Position may be 'right' or 'left'
		};
		var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
		var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
		s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
		var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
		})();
	</script>
	<!-- /WhatsHelp.io widget --> </body>
</html>
