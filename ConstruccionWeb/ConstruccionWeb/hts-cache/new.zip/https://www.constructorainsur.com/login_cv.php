<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>INSUR - constructora</title><link rel="shortcut icon" href="images/favicon.png"><meta name="description" content="Especialistas en las construcción de Naves y Obras Industriales" /><meta name="keywords" content="Construcción  de naves industriales, Construcción  de naves industriales Bajio, Construcción de naves industriales mexico, Construcción de naves industriales queretaro, Construcción de naves industriales san Luis potosi, Construcción industrial, Construcción industrial bajio, Construcción industrial mexico, Construcción industrial Queretaro, Construcción industrial San Luis potosi, Naves industriales, Naves industriales bajio, Naves industriales  Mexico, Naves industriales Queretaro, Naves industriales  San Luis potosi, Construcción obra civil, Construcción estructura metálica, Arquitectura industrial, Construcción de bodegas, Construcción de almacenes, Construcción de plantas de produccion, Construcción de cuartos limpios, Construcción alimenticia, Construcción farmacéutica, Construcción cimentaciones especiales"/><link href="css/boilerplate.css" rel="stylesheet" type="text/css" media="all"><link href="css/estilos.min.css" rel="stylesheet" type="text/css" media="all"><link href="https://fonts.googleapis.com/css?family=Roboto:400,900" rel="stylesheet">

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script async src="js/respond.min.js"></script><link href="css/owl.carousel.css" rel="stylesheet"><link href="css/owl.theme.css" rel="stylesheet"><link href="css/owl.transitions.css" rel="stylesheet"><link async href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">  <script src="assets/js/jquery-1.9.1.min.js"></script> <script src="js/owl.carousel.js"></script><style>#owl-demo .item img, #owl-demo_interna .item img, #owl-demo2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){var a=$("#owl-demo");a.owlCarousel({navigation:!1,singleItem:!0,transitionStyle:"fade",autoPlay:7e3}),$("#transitionType").change(function(){var t=$(this).val();a.data("owlCarousel").transitionTypes(t),a.trigger("owl.next")})});</script><script src='https://www.google.com/recaptcha/api.js'></script>	<style>#owl-demo_2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){$("#owl-demo_2").owlCarousel({navigation:!1,slideSpeed:300,singleItem:!0,autoPlay:!0,lazyLoad:!0})});</script><script type="text/javascript">$(document).on("scroll",function(){$(document).scrollTop()>360?($("#submenu").addClass("fijo"),$("#w_gale_proy").addClass("espacio")):($("#submenu").removeClass("fijo"),$("#w_gale_proy").removeClass("espacio"))}),$(document).ready(function(){$("#cerrar").click(function(){$("#example2_pop").hasClass("quitar")?($("#example2_pop").removeClass("quitar"),$("#cerrar").removeClass("girar")):($("#example2_pop").addClass("quitar"),$("#example2_pop_").addClass("quitar"),$("#cerrar").addClass("girar"))})}),$(document).ready(function(){$("#chat").click(function(){$("#example2_pop").hasClass("ver")?$("#example2_pop").removeClass("ver"):($("#example2_pop").addClass("ver"),$("#example2_pop_").addClass("ver"))})});</script><script>$(function(t){t("#submenu a").click(function(){var n=t(this).attr("href"),a=t(n).offset().top;return t("html:not(:animated),body:not(:animated)").animate({scrollTop:a},400),!1})});</script><script>function validar_contacto(){var e=document.getElementById("nombre").value,t=document.getElementById("email").value,n=document.getElementById("comentario").value;return 0==e.length?(alert("Ingresa tu nombre"),nombre.focus(),!1):0==t.length?(alert("Ingresa un correo electrónico"),email.focus(),!1):0==n.length?(alert("Dejanos tus comentarios"),comentario.focus(),!1):void 0}</script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-45144045-1"></script>
  
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 
  gtag('config', 'UA-45144045-1');
</script>
</head><body> 
    <div id="desc">
    	<img src="images/icono_desc.png">
        <h1>INGRESA LA INFORMACIÓN SOLICITADA</h1>
        <h2>DESCARGAR NUESTRO CV</h2>
                <form method="post" action="login_cv.php" style=" text-align: left">
        	<input type="hidden" name="bandera" value="1">
            <input type="text" class="input" name="nombre" id="nombre" placeholder="NOMBRE" style=" width: 100%"><br>
        	<input type="email" class="input" name="correo" id="correo" placeholder="E-MAIL" style=" width: 100%"><br>
            <input type="submit" class="input" value="Enviar" style=" background: #1b2b56; color: #fff; width: 150px">
        </form>
        <br>
            </div>
</body>
</html>
