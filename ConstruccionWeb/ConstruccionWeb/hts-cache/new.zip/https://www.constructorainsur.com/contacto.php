<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>INSUR - constructora</title><link rel="shortcut icon" href="images/favicon.png"><meta name="description" content="Especialistas en las construcción de Naves y Obras Industriales" /><meta name="keywords" content="Construcción  de naves industriales, Construcción  de naves industriales Bajio, Construcción de naves industriales mexico, Construcción de naves industriales queretaro, Construcción de naves industriales san Luis potosi, Construcción industrial, Construcción industrial bajio, Construcción industrial mexico, Construcción industrial Queretaro, Construcción industrial San Luis potosi, Naves industriales, Naves industriales bajio, Naves industriales  Mexico, Naves industriales Queretaro, Naves industriales  San Luis potosi, Construcción obra civil, Construcción estructura metálica, Arquitectura industrial, Construcción de bodegas, Construcción de almacenes, Construcción de plantas de produccion, Construcción de cuartos limpios, Construcción alimenticia, Construcción farmacéutica, Construcción cimentaciones especiales"/><link href="css/boilerplate.css" rel="stylesheet" type="text/css" media="all"><link href="css/estilos.min.css" rel="stylesheet" type="text/css" media="all"><link href="https://fonts.googleapis.com/css?family=Roboto:400,900" rel="stylesheet">

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script async src="js/respond.min.js"></script><link href="css/owl.carousel.css" rel="stylesheet"><link href="css/owl.theme.css" rel="stylesheet"><link href="css/owl.transitions.css" rel="stylesheet"><link async href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">  <script src="assets/js/jquery-1.9.1.min.js"></script> <script src="js/owl.carousel.js"></script><style>#owl-demo .item img, #owl-demo_interna .item img, #owl-demo2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){var a=$("#owl-demo");a.owlCarousel({navigation:!1,singleItem:!0,transitionStyle:"fade",autoPlay:7e3}),$("#transitionType").change(function(){var t=$(this).val();a.data("owlCarousel").transitionTypes(t),a.trigger("owl.next")})});</script><script src='https://www.google.com/recaptcha/api.js'></script>	<style>#owl-demo_2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){$("#owl-demo_2").owlCarousel({navigation:!1,slideSpeed:300,singleItem:!0,autoPlay:!0,lazyLoad:!0})});</script><script type="text/javascript">$(document).on("scroll",function(){$(document).scrollTop()>360?($("#submenu").addClass("fijo"),$("#w_gale_proy").addClass("espacio")):($("#submenu").removeClass("fijo"),$("#w_gale_proy").removeClass("espacio"))}),$(document).ready(function(){$("#cerrar").click(function(){$("#example2_pop").hasClass("quitar")?($("#example2_pop").removeClass("quitar"),$("#cerrar").removeClass("girar")):($("#example2_pop").addClass("quitar"),$("#example2_pop_").addClass("quitar"),$("#cerrar").addClass("girar"))})}),$(document).ready(function(){$("#chat").click(function(){$("#example2_pop").hasClass("ver")?$("#example2_pop").removeClass("ver"):($("#example2_pop").addClass("ver"),$("#example2_pop_").addClass("ver"))})});</script><script>$(function(t){t("#submenu a").click(function(){var n=t(this).attr("href"),a=t(n).offset().top;return t("html:not(:animated),body:not(:animated)").animate({scrollTop:a},400),!1})});</script><script>function validar_contacto(){var e=document.getElementById("nombre").value,t=document.getElementById("email").value,n=document.getElementById("comentario").value;return 0==e.length?(alert("Ingresa tu nombre"),nombre.focus(),!1):0==t.length?(alert("Ingresa un correo electrónico"),email.focus(),!1):0==n.length?(alert("Dejanos tus comentarios"),comentario.focus(),!1):void 0}</script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-45144045-1"></script>
  
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 
  gtag('config', 'UA-45144045-1');
</script>
</head>
<body>
    
    <ul class="navigation">
  <li> <a href="index.php" class="transition" >HOME</a> </li>
                    <li> <a href="conocenos.php" class="transition" >CONÓCENOS</a> </li>
                    <li> <a href="servicios.php" class="transition" >SERVICIOS</a> </li>
                    <li> <a href="proyectos.php" class="transition" >PROYECTOS</a> </li>
                    <li> <a href="clientes.php" class="transition" >CLIENTES</a> </li>
                    <li> <a href="contacto.php" class="activo transition" >CONTACTO</a> </li>
                    <li> <li> <a href="ing/contacto.php">ENG</a> </li> </li>

  <li><a href="mailto:info@constructorainsur.com">info@constructorainsur.com<br />(442) 215 3019</a></li>
</ul>
<input type="checkbox" id="nav-trigger" class="nav-trigger" />
<label for="nav-trigger"></label>
    <div class="site-wrap">
    <div id="logo_ip"><img class="logo" src="images/logo_menu.jpg" width="48%"/></div>

<div id="w_menu">
        <div class="gridContainer clearfix">
        	<div id="logo_menu"> <a href="index.php"><img src="images/logo_menu.jpg"></a> </div>
            <div id="menu">
            	<ul>
                	<li> <a href="index.php" class="transition" >home</a> </li>
                    <li> <a href="conocenos.php" class="transition" >conócenos</a> </li>
                    <li> <a href="servicios.php" class="transition" >servicios</a> </li>
                    <li> <a href="proyectos.php" class="transition" >proyectos</a> </li>
                    <li> <a href="clientes.php" class="transition" >clientes</a> </li>
                    <li> <a href="contacto.php" class="activo transition" >contacto</a> </li>
                    
                    <li> <a href="ing/contacto.php"><img src="images/idioma.png"> ENG</a> </li>                    
                </ul>
            </div>
            <div class="cleare"></div>
        
        </div>
    </div>
        
    <div id="top">
    	        <div id="redes"> 
        	<div id="face" class="redes_flotante"> <a href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"> <img src="images/face.png"></a> </div>
            <div id="idioma" class="redes_flotante"> <a href="#"><img src="images/idioma.png"> ENG</a></div>
        	<div class="cleare"></div>
        </div>        
        <div id="slide_internas" style=" background: url(images/slideofi.jpg) center / cover">
        	<div class="caption">MÁS DE 30 AÑOS<br>
            <span>RESPALDAN NUESTRO TRABAJO PROFESIONAL</span></div>
        </div>
       
    </div>
    
	<div id="w_contacto">
    <div id="w_maps">
    	<div id="google"> <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14941.432457721949!2d-100.361186!3d20.573428!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbce086aa08210637!2sConstructora+Insur!5e0!3m2!1sen!2smx!4v1486599037780" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe> </div>
        </div>
        <script>
    			$('#w_maps')
				.click(function(){
				$(this).find('iframe').addClass('clicked')})
				.mouseleave(function(){
				$(this).find('iframe').removeClass('clicked')});
    			</script>
    	<div id="form">
        	<h1 class="titulo" style=" padding: 7vh 0 0 0">CONTACTO</h1>
            
            <p id="fullp">
            <span style=" color: #000">Querétaro</span><br>
            Av. Ing. Armando Birlain No. 2001, Piso 2-A<br>
            Corporativo 2 Central Park, CP. 76090, Col Centro Sur<br>
            Santiago de Querétaro, Qro.<br>
            Tel. (442) 215 3019<br><br>

            <span style=" color: #000">San Luis Potosí</span><br>
            Av. Cordillera de los Himalaya No. 1018 <br>
            Frac. Lomas 4ta Sección CP. 78216<br>
            San Luis Potosí, SLP.<br>
            Tel (444) 246 5250<br><br>
            <a href="mailto:info@constructorainsur.com" style=" color: #000">info@constructorainsur.com</a></p>
            
            <div id="formm">
                        
            <form action="contacto.php#w_contacto"  method="post"  onSubmit="return validar_contacto()">
                <input type="hidden" name="bandera" value="1">
            	<input type="text" class="input" name="nombre" id="nombre" placeholder="Nombre">
                <input type="text" class="input" name="tel" id="tel" placeholder="Tel">
                <input type="email" class="input" name="email" id="email" placeholder="Email">
                <textarea class="input" name="comentario" id="comentario" placeholder="Mensaje" style=" height: 100px;"></textarea>
                <div class="recaptcha-wrap2">                   
                	<div class="g-recaptcha" data-theme="dark" data-sitekey="6LdAgSAUAAAAABx5tHLNEmrGw57BIqRbj7DyXk7X"></div>
				</div>
                <input type="submit" class="input mandar" value="Enviar" style=" background: #1b2b56; color: #fff;">
            </form>
            
                        </div>
        </div>
        <div class="cleare"></div>
    </div>
    
    <div id="w_footer" style="letter-spacing:1px">
    	<div class="gridContainer clearfix">
        	<div id="logo_ft"> <img src="images/logo_ft.png"> <p>®2020, DERECHOS RESERVADOS</p> </div>
            <div id="redes_ft"> <p>Tel. (442) 215 3019 /</p>
            <a href="mailto:info@constructorainsur.com" style=" color: #fff">info@constructorainsur.com</a>
            <a id="fbfull" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fbfull" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fbfull" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fbfull" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
            </div>
            <a id="fb" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fb" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fb" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fb" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
        	<div class="cleare"></div>
        </div>
    </div>

<!--fin de responsive-->
</div>
<div class="quitar--caca">

    <link rel="stylesheet" href="css/flickity.css" media="screen">
    <script src="js/flickity.pkgd.js"></script>
    <script src="js/flickity-docs.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.main-carousel').flickity({
                // options
                cellAlign: 'left',
                groupCells: 3,
                imagesLoaded: true,
                pageDots: false,
                autoPlay: 6000,
            });
        });
    </script>
</div>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
		(function () {
		var options = {
		whatsapp: "+524423150697", // WhatsApp number
		call_to_action: "Escríbenos", // Call to action
		position: "right", // Position may be 'right' or 'left'
		};
		var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
		var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
		s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
		var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
		})();
	</script>
	<!-- /WhatsHelp.io widget --> 
</body>
</html>
