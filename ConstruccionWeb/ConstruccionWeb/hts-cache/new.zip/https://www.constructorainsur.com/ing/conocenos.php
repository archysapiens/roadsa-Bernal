<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="">
<!--<![endif]-->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>INSUR - constructora</title>
<link rel="shortcut icon" href="../images/favicon.png">
<link href="../css/boilerplate.css" rel="stylesheet" type="text/css">
<link href="../css/estilos.css" rel="stylesheet" type="text/css">

<link href="https://fonts.googleapis.com/css?family=Roboto:400,900" rel="stylesheet">

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="../js/respond.min.js"></script>

<!-- Owl Carousel Assets -->
<link href="../css/owl.carousel.css" rel="stylesheet">
<link href="../css/owl.theme.css" rel="stylesheet">
<link href="../css/owl.transitions.css" rel="stylesheet">
<link href="../assets/js/google-code-prettify/prettify.css" rel="stylesheet">  
<script src="../assets/js/jquery-1.9.1.min.js"></script> 
<script src="../js/owl.carousel.js"></script>

<!-- Demo -->
<style>
    #owl-demo .item img, #owl-demo_interna .item img, #owl-demo2 .item img{
        display: block;
        width: 100%;
        height: auto;
    }
</style>

<script>
    $(document).ready(function() {
      var owl = $("#owl-demo");
      owl.owlCarousel({
        navigation : false,
        singleItem : true,
        transitionStyle : "fade",
		autoPlay: 7000,
      });
	  
      $("#transitionType").change(function(){
        var newValue = $(this).val();
        owl.data("owlCarousel").transitionTypes(newValue);
        owl.trigger("owl.next");
      });
    });

</script>

<link rel="stylesheet" href="../css/flickity.css" media="screen">
<script src="../js/flickity.pkgd.js"></script>
<script src="../js/flickity-docs.min.js"></script>
<script>
    $(document).ready(function() {
		$('.carousel').flickity({
		  // options
		  cellAlign: 'left',
		  groupCells: true,
		  imagesLoaded: true,
		  pageDots: false,
		  autoPlay: 6000,
		});
	});
</script>
<script>
    $(document).ready(function() {
		$('.main-carousel').flickity({
		  // options
		  cellAlign: 'left',
		  groupCells: true,
		  imagesLoaded: true,
		  pageDots: false,
		  autoPlay: 6000,
		});
	});
</script>

<script src='https://www.google.com/recaptcha/api.js'></script>	
<script type="text/javascript" src="../js/custom.js"></script>

<style>
#owl-demo_2 .item img{
	display: block;
	width: 100%;
	height: auto;
}
</style>
<script>
$(document).ready(function() {
      $("#owl-demo_2").owlCarousel({
      navigation : false,
      slideSpeed : 300,
      singleItem : true,
	  autoPlay: true,
	  lazyLoad : true,
      });
});
</script>

<!--<script language="JavaScript">
document.writeln(screen.width)
</script>-->

<script src="../js/jquery-latest.js"></script>
<script type="text/javascript">	
	
	$(document).on("scroll",function(){
		if($(document).scrollTop()>360){ 
			$("#submenu").addClass("fijo");
			$("#w_gale_proy").addClass("espacio");
		} else {
			$("#submenu").removeClass("fijo");
			$("#w_gale_proy").removeClass("espacio");
		}
	});
	$(document).ready(function() {
    $('#cerrar').click(function() {
		if ($('#example2_pop').hasClass('quitar')) {
				$('#example2_pop').removeClass('quitar');
				$('#cerrar').removeClass('girar');
		} else {
			$('#example2_pop').addClass('quitar');
			$('#example2_pop_').addClass('quitar');
			$('#cerrar').addClass('girar');
			}
		});
	});

	$(document).ready(function() {
    $('#chat').click(function() {
		if ($('#example2_pop').hasClass('ver')) {
				$('#example2_pop').removeClass('ver');
		} else {
			$('#example2_pop').addClass('ver');
			$('#example2_pop_').addClass('ver');
			}
		});
	});
</script>

<!-- Add jQuery library -->
	<script type="text/javascript" src="../lib/jquery-1.10.1.min.js"></script>

	<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="../js/jquery.mousewheel-3.0.6.pack.js"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="../source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="../source/jquery.fancybox.css?v=2.1.5" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="../source/helpers/jquery.fancybox-buttons.css?v=1.0.5" />
	<script type="text/javascript" src="../source/helpers/jquery.fancybox-buttons.js?v=1.0.5"></script>

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="../source/helpers/jquery.fancybox-thumbs.css?v=1.0.7" />
	<script type="text/javascript" src="../source/helpers/jquery.fancybox-thumbs.js?v=1.0.7"></script>

	<!-- Add Media helper (this is optional) -->
	<script type="text/javascript" src="../source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>

	<script type="text/javascript">
		$(document).ready(function() {
			/*
			 *  Simple image gallery. Uses default settings
			 */

			$('.fancybox').fancybox();

			/*
			 *  Different effects
			 */

			// Change title type, overlay closing speed
			$(".fancybox-effects-a").fancybox({
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});

			// Disable opening and closing animations, change title type
			$(".fancybox-effects-b").fancybox({
				openEffect  : 'none',
				closeEffect	: 'none',

				helpers : {
					title : {
						type : 'over'
					}
				}
			});

			// Set custom style, close if clicked, change title type and overlay color
			$(".fancybox-effects-c").fancybox({
				wrapCSS    : 'fancybox-custom',
				closeClick : true,

				openEffect : 'none',

				helpers : {
					title : {
						type : 'inside'
					},
					overlay : {
						css : {
							'background' : 'rgba(238,238,238,0.85)'
						}
					}
				}
			});

			// Remove padding, set opening and closing animations, close if clicked and disable overlay
			$(".fancybox-effects-d").fancybox({
				padding: 0,

				openEffect : 'elastic',
				openSpeed  : 150,

				closeEffect : 'elastic',
				closeSpeed  : 150,

				closeClick : true,

				helpers : {
					overlay : null
				}
			});

			/*
			 *  Button helper. Disable animations, hide close button, change title type and content
			 */

			$('.fancybox-buttons').fancybox({
				openEffect  : 'none',
				closeEffect : 'none',

				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,

				helpers : {
					title : {
						type : 'inside'
					},
					buttons	: {}
				},

				afterLoad : function() {
					this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
				}
			});


			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			 */

			$('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			/*
			 *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
			*/
			$('.fancybox-media')
				.attr('rel', 'media-gallery')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',

					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});

			/*
			 *  Open manually
			 */

			$("#fancybox-manual-a").click(function() {
				$.fancybox.open('1_b.jpg');
			});

			$("#fancybox-manual-b").click(function() {
				$.fancybox.open({
					href : 's.php',
					type : 'iframe',
					padding : 5
				});
			});

			$("#fancybox-manual-c").click(function() {
				$.fancybox.open([
					{
						href : '1_b.jpg',
						title : 'My title'
					}, {
						href : '2_b.jpg',
						title : '2nd title'
					}, {
						href : '3_b.jpg'
					}
				], {
					helpers : {
						thumbs : {
							width: 75,
							height: 50
						}
					}
				});
			});


		});
	</script>
	<style type="text/css">
		.fancybox-custom .fancybox-skin {
			box-shadow: 0 0 50px #222;
		}
	</style>

<script>
$(function($){
	   $('#submenu a').click(function() {
			var $this = $(this),
			  _href = $this.attr('href'),
					dest  = $(_href).offset().top;
				$("html:not(:animated),body:not(:animated)").animate({  scrollTop: dest}, 400 );
			return false;
		}); 
	});


//$(document).on("scroll",function(){
//		if($(document).scrollTop()>360){ 
//			$('html, body').animate({
//        		scrollTop: $('#w_bienvenido').offset().top
//    		}, 'slow');
//		}
//	});

	</script>

</head>
<body>
    
	<ul class="navigation">
  <li> <a href="index.php" class="transition" >HOME</a> </li>
                    <li> <a href="conocenos.php" class="activo transition" >ABOUT</a> </li>
                    <li> <a href="servicios.php" class="transition" >SERVICES</a> </li>
                    <li> <a href="proyectos.php" class="transition" >PROYECTS</a> </li>
                    <li> <a href="clientes.php" class="transition" >CUSTOMERS</a> </li>
                    <li> <a href="contacto.php" class="transition" >CONTACT</a> </li>
                    <li><li> <a href="../conocenos.php">ESP</a> </li></li>

  <li><a href="mailto:info@constructorainsur.com">info@constructorainsur.com<br />(442) 215 3019</a></li>
</ul>
<input type="checkbox" id="nav-trigger" class="nav-trigger" />
<label for="nav-trigger"></label>
    <div class="site-wrap">
    <div id="logo_ip"><img class="logo" src="../images/logo_menu.jpg" width="48%"/></div>

<div id="w_menu">
        <div class="gridContainer clearfix">
        	<div id="logo_menu"> <a href="index.php"><img src="../images/logo_menu.jpg"></a> </div>
            <div id="menu">
            	<ul>
                	<li> <a href="index.php" class="transition" >home</a> </li>
                    <li> <a href="conocenos.php" class="activo transition" >about</a> </li>
                    <li> <a href="servicios.php" class="transition" >services</a> </li>
                    <li> <a href="proyectos.php" class="transition" >projects</a> </li>
                    <li> <a href="clientes.php" class="transition" >CLIENTS</a> </li>
                    <li> <a href="contacto.php" class="transition" >contact</a> </li>
                    
                    <li> <a href="../conocenos.php"><img src="../images/idioma.png"> ESP</a> </li>                    
                </ul>
            </div>
            <div class="cleare"></div>
        
        </div>
    </div>
        
    <div id="top">
    	        <div id="redes"> 
        	<div id="face" class="redes_flotante"> <a href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"> <img src="images/face.png"></a> </div>
            <div id="idioma" class="redes_flotante"> <a href="#"><img src="images/idioma.png"> ENG</a></div>
        	<div class="cleare"></div>
        </div>        
        <div id="slide_internas" style=" background: url(../images/slideofi.jpg) center / cover">
        	<div class="caption">MORE THAN 35 YEARS<br><!--<hr style=" width: 30px; text-align: center">--><span>SUPPORT OUR PROFESSIONAL WORK</span></div>
        </div>
        
    	<!--<div id="w_slide">
            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div id="owl-demo" class="owl-carousel">
                            <div class="item" style=" position:relative"> <div class="caption">MÁS DE 30 AÑOS <br><hr style=" width: 30px; text-align: center"><span>RESPALDAN NUESTRO TRABAJO PROFESIONAL</span></div> <img src="../images/slideofi.jpg"> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="scroll"> <img src="../images/scrolldown.png"> </div>-->
    </div>
    
    
    
    <div id="w_conocenos">
    	<h1 class="titulo" id="titulo_abs" style=" top:50px">ABOUT US</h1>
        <div id="izq_cono">
        	<div id="mergenes">
                <img src="../images/35_.png">
                <p><span class="capitalLetter">W</span>e are a group of specialists in all the areas that compose the construction process with more than 32 years of experience With the vision of strengthening the industrial and economic growth of our country CONSTRUCTORA INSUR develops industrial plants, warehouses and commercial buildings , Responding in a professional way and working as a team with our clients to solve and create projects that exceed their expectations, turning big ideas into big constructions. </p>
				<br>
                <a href="login_cv.php" id="btn_descarga" class="fancybox" data-fancybox-type="iframe">DOWNLOAD OUR CV</a>
            </div>
        </div>
        <div id="r_cono">
        	<div class="container">
            	<div class="row">
                	<div class="span12">
                    	<div id="owl-demo_2" class="owl-carousel">
                        <div class="item" style=" position:relative"> <img src="../images/serv1_.jpg"> </div><div class="item" style=" position:relative"> <img src="../images/serv2_.jpg"> </div><div class="item" style=" position:relative"> <img src="../images/serv3_.jpg"> </div>                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div id="w_ventajas" class="para_conocenos" style=" position: relative">
    	<div class="gridContainer clearfix">
            
            <div class="uno_uno">
            	<div class="txt_ventajas_l">
                    <h1>WE HAVE HIGHLY TRAINED STAFF</h1>
                    <p>Focused on competitiveness, we use state-of-the-art technology and systems, in order to always remain the most viable option in the market. Likewise, the people who make up the INSUR Family are constantly learning and updating to develop great projects.</p>
                </div>
                <div class="img_ventajas_l resmar" id="capacitados" style=" height: 150px; background: url(../images/DSC_0008.JPG) repeat scroll center center / cover ;""></div>
                <div class="linea_ch"></div>
                <div class="cleare"></div>
            </div>
            
            <div class="uno_uno">
                <div class="img_ventajas_l" id="ejecucion" style=" height: 110px; background: url(../images/DSC_0041.JPG) repeat scroll center center / cover ;""></div>
                <div class="txt_ventajas_r">
                    <h1>IN THE EXECUTION OF EACH PROJECT, WE APPLY OUR PHILOSOPHY OF SERVICE AND COMPETITIVENESS</h1>
                    <p style=" font-size: 16px; line-height: 22px">Realizing aesthetic constructions, functional and with excellent engineering of design, we offer alternatives of maximum SAFETY AND ECONOMY and with reduced times of delivery.</p>
                </div>
                <div class="img_ventajas_l resmar" id="ejecucion2" style=" height: 110px; background: url(../images/DSC_0041.JPG) repeat scroll center center / cover ;"></div>
                <div class="linea_ch"></div>
                <div class="cleare"></div>
            </div>
            <div class="cleare"></div>
            
        </div>
    </div>
    
    <div id="w_mision">
    	<div class="gridContainer clearfix">
            <div class="detalle" style="background: url(../images/bg_conocenos.jpg) center / cover; top: -200px; height: 130px">
                AESTHETICS, FUNCTIONAL<br>AND WITH EXCELLENT DESIGN ENGINEERING
            </div>
            <div class="casquin"> <img src="../images/casquin.png"> </div>
            <div class="flotante_mis">
            	<h1>MISSION</h1>
            	To be the best option in the market for construction of ships and industrial works in the central region of the country, demonstrating our experience and combining it with the adaptation and innovation of new technologies, understanding and fulfilling the needs of our customers.
            </div>
            <div class="flotante_mis">
            	<h1>VISION</h1>
            	To offer our services nationwide, positioning ourselves within Mexico's top 20 industrial constructors, developing and implementing innovative technologies to make them more efficient.
            </div>
            <div class="cleare"></div>
        </div>
    </div>
    
    <div id="w_footer" style="letter-spacing:1px">
    	<div class="gridContainer clearfix">
        	<div id="logo_ft"> <img src="../images/logo_ft.png"> <p>®2020, ALL RIGHTS RESERVED</p> </div>
            <div id="redes_ft"> <p>Tel. (442) 215 3019 /</p> <a href="mailto:info@constructorainsur.com" style=" color: #fff">info@constructorainsur.com</a>
            <a id="fbfull" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="../images/face_ft.png"></a>
            <a id="fbfull" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="../images/twitter_ft.png"></a>
            <a id="fbfull" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="../images/linked_ft.png"></a>
            <a id="fbfull" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="../images/instagram_ft.png"></a>
            </div>
            <a id="fb" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="../images/face_ft.png"></a>
            <a id="fb" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="../images/twitter_ft.png"></a>
            <a id="fb" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="../images/linked_ft.png"></a>
            <a id="fb" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="../images/instagram_ft.png"></a>
        	<div class="cleare"></div>
        </div>
    </div>

<!--fin de responsive-->
</div>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
		(function () {
		var options = {
		whatsapp: "+524423150697", // WhatsApp number
		call_to_action: "Contact us", // Call to action
		position: "right", // Position may be 'right' or 'left'
		};
		var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
		var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
		s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
		var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
		})();
	</script>
	<!-- /WhatsHelp.io widget --> 
</body>
</html>
