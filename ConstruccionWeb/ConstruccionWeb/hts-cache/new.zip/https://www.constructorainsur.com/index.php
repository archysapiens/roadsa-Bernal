<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>INSUR - constructora</title><link rel="shortcut icon" href="images/favicon.png"><meta name="description" content="Especialistas en las construcción de Naves y Obras Industriales" /><meta name="keywords" content="Construcción  de naves industriales, Construcción  de naves industriales Bajio, Construcción de naves industriales mexico, Construcción de naves industriales queretaro, Construcción de naves industriales san Luis potosi, Construcción industrial, Construcción industrial bajio, Construcción industrial mexico, Construcción industrial Queretaro, Construcción industrial San Luis potosi, Naves industriales, Naves industriales bajio, Naves industriales  Mexico, Naves industriales Queretaro, Naves industriales  San Luis potosi, Construcción obra civil, Construcción estructura metálica, Arquitectura industrial, Construcción de bodegas, Construcción de almacenes, Construcción de plantas de produccion, Construcción de cuartos limpios, Construcción alimenticia, Construcción farmacéutica, Construcción cimentaciones especiales"/><link href="css/boilerplate.css" rel="stylesheet" type="text/css" media="all"><link href="css/estilos.min.css" rel="stylesheet" type="text/css" media="all"><link href="https://fonts.googleapis.com/css?family=Roboto:400,900" rel="stylesheet">

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script async src="js/respond.min.js"></script><link href="css/owl.carousel.css" rel="stylesheet"><link href="css/owl.theme.css" rel="stylesheet"><link href="css/owl.transitions.css" rel="stylesheet"><link async href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">  <script src="assets/js/jquery-1.9.1.min.js"></script> <script src="js/owl.carousel.js"></script><style>#owl-demo .item img, #owl-demo_interna .item img, #owl-demo2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){var a=$("#owl-demo");a.owlCarousel({navigation:!1,singleItem:!0,transitionStyle:"fade",autoPlay:7e3}),$("#transitionType").change(function(){var t=$(this).val();a.data("owlCarousel").transitionTypes(t),a.trigger("owl.next")})});</script><script src='https://www.google.com/recaptcha/api.js'></script>	<style>#owl-demo_2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){$("#owl-demo_2").owlCarousel({navigation:!1,slideSpeed:300,singleItem:!0,autoPlay:!0,lazyLoad:!0})});</script><script type="text/javascript">$(document).on("scroll",function(){$(document).scrollTop()>360?($("#submenu").addClass("fijo"),$("#w_gale_proy").addClass("espacio")):($("#submenu").removeClass("fijo"),$("#w_gale_proy").removeClass("espacio"))}),$(document).ready(function(){$("#cerrar").click(function(){$("#example2_pop").hasClass("quitar")?($("#example2_pop").removeClass("quitar"),$("#cerrar").removeClass("girar")):($("#example2_pop").addClass("quitar"),$("#example2_pop_").addClass("quitar"),$("#cerrar").addClass("girar"))})}),$(document).ready(function(){$("#chat").click(function(){$("#example2_pop").hasClass("ver")?$("#example2_pop").removeClass("ver"):($("#example2_pop").addClass("ver"),$("#example2_pop_").addClass("ver"))})});</script><script>$(function(t){t("#submenu a").click(function(){var n=t(this).attr("href"),a=t(n).offset().top;return t("html:not(:animated),body:not(:animated)").animate({scrollTop:a},400),!1})});</script><script>function validar_contacto(){var e=document.getElementById("nombre").value,t=document.getElementById("email").value,n=document.getElementById("comentario").value;return 0==e.length?(alert("Ingresa tu nombre"),nombre.focus(),!1):0==t.length?(alert("Ingresa un correo electrónico"),email.focus(),!1):0==n.length?(alert("Dejanos tus comentarios"),comentario.focus(),!1):void 0}</script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-45144045-1"></script>
  
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 
  gtag('config', 'UA-45144045-1');
</script>
</head>
<body>
   
   <ul class="navigation">
  <li> <a href="index.php" class="activo transition" >HOME</a> </li>
                    <li> <a href="conocenos.php" class="transition" >CONÓCENOS</a> </li>
                    <li> <a href="servicios.php" class="transition" >SERVICIOS</a> </li>
                    <li> <a href="proyectos.php" class="transition" >PROYECTOS</a> </li>
                    <li> <a href="clientes.php" class="transition" >CLIENTES</a> </li>
                    <li> <a href="contacto.php" class="transition" >CONTACTO</a> </li>
                    <li> <li> <a href="ing">ENG</a> </li> </li>

  <li><a href="mailto:info@constructorainsur.com">info@constructorainsur.com<br />(442) 215 3019</a></li>
</ul>
<input type="checkbox" id="nav-trigger" class="nav-trigger" />
<label for="nav-trigger"></label>
    <div class="site-wrap">
    <div id="logo_ip"><img class="logo" src="images/logo_menu.jpg" width="48%"/></div>

<div id="w_menu">
        <div class="gridContainer clearfix">
        	<div id="logo_menu"> <a href="index.php"><img src="images/logo_menu.jpg"></a> </div>
            <div id="menu">
            	<ul>
                	<li> <a href="index.php" class="activo transition" >home</a> </li>
                    <li> <a href="conocenos.php" class="transition" >conócenos</a> </li>
                    <li> <a href="servicios.php" class="transition" >servicios</a> </li>
                    <li> <a href="proyectos.php" class="transition" >proyectos</a> </li>
                    <li> <a href="clientes.php" class="transition" >clientes</a> </li>
                    <li> <a href="contacto.php" class="transition" >contacto</a> </li>
                    
                    <li> <a href="ing"><img src="images/idioma.png"> ENG</a> </li>                    
                </ul>
            </div>
            <div class="cleare"></div>
        
        </div>
    </div>
        
    

    <div id="top">
    	        <div id="redes"> 
        	<div id="face" class="redes_flotante"> <a href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"> <img src="images/face.png"></a> </div>
            <div id="idioma" class="redes_flotante"> <a href="#"><img src="images/idioma.png"> ENG</a></div>
        	<div class="cleare"></div>
        </div>    	<div id="w_slide">
            <div class="container">
                <div class="row">
                    <div class="span12">
                        <div id="owl-demo" class="owl-carousel">
                        <div class="item" style=" position:relative"><div class="caption"> <br><!--<hr style=" width: 30px; text-align: center">--><span></span></div><img src="images/insur-aniversario-logo.jpg" srcset="images/insur-aniversario-logo.jpg 1920px" sizes="100%"></div><div class="item" style=" position:relative"><div class="caption">EXPERTOS <br><!--<hr style=" width: 30px; text-align: center">--><span>EN LA CONSTRUCCIÓN DE NAVES INDUSTRIALES</span></div><img src="images/insur-slide1.jpg" srcset="images/insur-slide1.jpg 1920px" sizes="100%"></div><div class="item" style=" position:relative"><div class="caption">EXCELENTE <br><!--<hr style=" width: 30px; text-align: center">--><span>INGENIERÍA EN DISEÑO</span></div><img src="images/insur-slide2.jpg" srcset="images/insur-slide2.jpg 1920px" sizes="100%"></div><div class="item" style=" position:relative"><div class="caption">MÁS DE 35 AÑOS <br><!--<hr style=" width: 30px; text-align: center">--><span>RESPALDAN NUESTRO TRABAJO PROFESIONAL</span></div><img src="images/inur-slide3.jpg" srcset="images/inur-slide3.jpg 1920px" sizes="100%"></div>                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="scroll"> <img src="images/scrolldown.png"> </div>
    </div>
    
    <div id="w_bienvenido">
    	<div class="gridContainer clearfix">
        	<h1 class="titulo" style=" text-align: center">BIENVENIDO</h1>
            <br><br>            
            <div id="treinta"> <img src="images/35.png" srcset="images/35.png 505px" sizes="100%"> </div>
            <div id="texto_bienvenido">
            	<p><span class="capitalLetter">C</span>on la visión de fortalecer al crecimiento industrial y económico de nuestro país CONSTRUCTORA INSUR nace hace 35 años, conformado por un grupo de especialistas en cada área que compone el proceso de construcción de plantas industriales, bodegas y edificios comerciales, respondiendo de manera profesional y trabajando en equipo con nuestros clientes para resolver y crear proyectos que superen sus expectativas, convirtiendo grandes ideas en grandes construcciones. </span></p>
            </div>
            <div id="botones_mas">
            	<a href="conocenos.php" id="btn_ver_mas" class="transition">VER MÁS</a>
                <a href="login_cv.php" id="btn_descarga" class="fancybox" data-fancybox-type="iframe">DESCARGA NUESTRO FOLLETO</a>
            	<div class="cleare"></div>
            </div>
            <div class="cleare"></div>
        </div>
        <div id="bicolor"></div>
    </div>
    

    <div id="w_gale_proy" style="margin-top:0">
        <div id="thumb">
            <div class="gridContainer clearfix">
                <h1 class="titulo" style=" text-align: center;">PROYECTOS RECIENTES</h1><br><br>
            <div class="thumb_flotante thumb_flotante-home"><a href="detalle.php?tipo=concluidos&proyecto=4" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Nucitec</div><div class="fecha"> 2014 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/DSC_0184.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante thumb_flotante-home"><a href="detalle.php?tipo=concluidos&proyecto=27" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/alemania.png"> B.Braun</div><div class="fecha"> 2018 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/BBRAUN_01.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante thumb_flotante-home"><a href="detalle.php?tipo=concluidos&proyecto=1" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/mexico.png"> Truper</div><div class="fecha"> 2012 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/truper.png) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante thumb_flotante-home"><a href="detalle.php?tipo=concluidos&proyecto=6" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/canada.png"> Narmx</div><div class="fecha"> 2016 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/NARMX-1.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante thumb_flotante-home"><a href="detalle.php?tipo=concluidos&proyecto=8" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/china.png"> Aceway</div><div class="fecha"> 2015 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/IMG_0821.JPG) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div><div class="thumb_flotante thumb_flotante-home"><a href="detalle.php?tipo=concluidos&proyecto=15" class="transition"><div class="w_titulo_fecha"><div class="titulo_proy"> <img src="images/alemania.png"> Ronal</div><div class="fecha"> 2015 </div><div class="cleare"></div></div><div class="foto_proy" style=" background: url(images/proyectos/ronal.jpg) center / cover"><div class="btn_mas_proy"> <img src="images/btn_serv_mas.png"> </div><div class="over"></div></div></a></div>            <div class="cleare"></div>
                <div class="btt">
                    <a href="proyectos.php" id="btn_descarga">VER MÁS PROYECTOS</a>
                </div>
            </div>
        </div>
    </div>



    <div id="w_serv">
    	<div class="gridContainer clearfix">
        	<h1 class="titulo">SERVICIOS</h1>
            <br><br>
        </div>
        
        <div id="ver_mac" class="carousel--show-several" data-flickity="{ &quot;groupCells&quot;: 3, &quot;pageDots&quot;: false, &quot;autoPlay&quot;: 6000 }">
        	
            	<div class="carousel-cell">
					<a href="servicios.php#construccion" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>CONSTRUCCIÓN DE OBRA CIVIL</h1>
                                <p >Trabajamos con gran ritmo, eficiencia y rendimiento económico  la construcción de Accesos, Vialidades, Estacionamientos y Patios de Maniobras, así como todo tipo de Urbanizaciones, de esta forma nos comprometemos con nuestros clientes a entregar a tiempo y en orden.</p>
                                <!-- <div class="indicador_hacia_abajo"> <img src="images/indicador.png"> </div> -->
                            </div>
                            <div class="foto" id="construccion">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#estudios" class="transition">
                    	<div class="w_serv_slide">
                            <div class="foto" id="estudios_preliminares">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                            <div class="texto_arriba">
                            	<h1>ESTUDIOS PRELIMINARES</h1>
                                <p >Enfocados en la realización de proyectos integrales, en Constructora Insur ofrecemos un grupo de profesionales en gestión y ejecución de planimetría como proceso complementario al desarrollo de proyectos de la  construcción. </p>
                                <!-- <div class="indicador_hacia_arriba"> <img src="images/indicador_arriba.png"> </div> -->
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#terracerias" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>TERRACERÍAS</h1>
                                <p >Para cualquier desarrollo y construcción, el manejo de suelos representa una piedra angular para acceso, soporte y planeación de la obra, ofrecemos soluciones en Cortes, Rellenos, Nivelaciones y Mejoramiento de Suelos</p>
                            </div>
                            <div class="foto" id="terracerias">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#arquitectonicos" class="transition">
                    	<div class="w_serv_slide">
                            <div class="foto" id="arquitectonicos">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                            <div class="texto_arriba">
                            	<h1>PROYECTOS ARQUITECTÓNICOS</h1>
                                <p >En Insur cada proyecto representa un compromiso profundo con la calidad, para lograr esto conjugamos elementos clave de nuestro equipo para trabajar con nuestros clientes y poder desarrollar así proyectos a la altura de las expectativas. </p>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#edificacion" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>EDIFICACIÓN</h1>
                                <p >Queremos convertir grandes ideas en grandes construcciones, por ello en Insur establecemos y ejecutamos modelos y planes de trabajo estructurado para lograr levantar cualquier edificación.</p>
                            </div>
                            <div class="foto" id="serv_edificacion">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#estructuras" class="transition">
                    	<div class="w_serv_slide">
                            <div class="foto" id="serv_metalicas">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                            <div class="texto_arriba">
                            	<h1>ESTRUCTURAS METÁLICAS Y CUBIERTAS</h1>
                                <p >Con tres décadas de experiencia, en Insur estamos orgullosos de poder contribuir en con nuestros clientes desde el primer momento, te ofrecemos Diseño, Fabricación, Transporte y Montaje de estructuras metálicas.</p>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#cuartos" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>CUARTOS LIMPIOS</h1>
                                <p >En INSUR, ofrecemos el servicio especializado para cada tipo de industria con la finalidad de satisfacer sus necesidades y resolver cualquier problema, para el ramo alimenticio ofrecemos la construcción de cuartos o aéreas limpias diseñadas para cumplir con requerimientos y normas que garanticen un estado prístino de tratamiento de insumos.</p>
                            </div>
                            <div class="foto" id="serv_cuartos">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#cimientos" class="transition">
                    	<div class="w_serv_slide">
                            <div class="foto" id="serv_cimientos_especiales">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                            <div class="texto_arriba">
                            	<h1>CIMIENTOS ESPECIALES</h1>
                                <p >Diseñamos, calculamos y ejecutamos cimentaciones especiales de acuerdo a las necesidades de cada industria, planeamos y ejecutamos proyectos de cimentación de prensas y cimentación para silos.</p>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell">
					<a href="servicios.php#instalaciones" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>INSTALACIONES INDUSTRIALES</h1>
                                <p >Planeamos, diseñamos, calculamos distribuimos y pensamos como un grupo especializado para el desarrollo de instalaciones industriales que cumplan con todas las funcionalidades e importancia que requieren los proyectos de nuestros clientes.</p>
                            </div>
                            <div class="foto" id="serv_instalaciones_industriales">
                            	<div class="btn_mas_serv"> <img src="images/btn_serv_mas.png"> </div>
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
			</div>
            
            <div id="ver_iphone">
        	
            	<div class="carousel-cell_">
					<a href="servicios.php#construccion" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>CONSTRUCCIÓN DE OBRA CIVIL</h1>
                                <p >Trabajamos con gran ritmo, eficiencia y rendimiento económico  la construcción de Accesos, Vialidades, Estacionamientos y Patios de Maniobras, así como todo tipo de Urbanizaciones, de esta forma nos comprometemos con nuestros clientes a entregar a tiempo y en orden.</p>
                            </div>
                            <div class="foto" id="construccion">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#estudios" class="transition">
                    	<div class="w_serv_slide">
							<div class="texto_arriba">
                            	<h1>ESTUDIOS PRELIMINARES</h1>
                                <p >Enfocados en la realización de proyectos integrales, en Constructora Insur ofrecemos un grupo de profesionales en gestión y ejecución de planimetría como proceso complementario al desarrollo de proyectos de la  construcción. </p>
                            </div>
                            <div class="foto" id="estudios_preliminares">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#terracerias" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>TERRACERÍAS</h1>
                                <p >Para cualquier desarrollo y construcción, el manejo de suelos representa una piedra angular para acceso, soporte y planeación de la obra, ofrecemos soluciones en Cortes, Rellenos, Nivelaciones y Mejoramiento de Suelos</p>
                            </div>
                            <div class="foto" id="terracerias">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#arquitectonicos" class="transition">
                    	<div class="w_serv_slide">
							<div class="texto_arriba">
                            	<h1>PROYECTOS ARQUITECTÓNICOS</h1>
                                <p >En Insur cada proyecto representa un compromiso profundo con la calidad, para lograr esto conjugamos elementos clave de nuestro equipo para trabajar con nuestros clientes y poder desarrollar así proyectos a la altura de las expectativas. </p>
                            </div>
                            <div class="foto" id="arquitectonicos">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#edificacion" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>EDIFICACIÓN</h1>
                                <p >Queremos convertir grandes ideas en grandes construcciones, por ello en Insur establecemos y ejecutamos modelos y planes de trabajo estructurado para lograr levantar cualquier edificación.</p>
                            </div>
                            <div class="foto" id="serv_edificacion">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#estructuras" class="transition">
                    	<div class="w_serv_slide">
							<div class="texto_arriba">
                            	<h1>ESTRUCTURAS METÁLICAS Y CUBIERTAS</h1>
                                <p >Con tres décadas de experiencia, en Insur estamos orgullosos de poder contribuir en con nuestros clientes desde el primer momento, te ofrecemos Diseño, Fabricación, Transporte y Montaje de estructuras metálicas.</p>
                            </div>
                            <div class="foto" id="serv_metalicas">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#cuartos" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>CUARTOS LIMPIOS</h1>
                                <p >En INSUR, ofrecemos el servicio especializado para cada tipo de industria con la finalidad de satisfacer sus necesidades y resolver cualquier problema, para el ramo alimenticio ofrecemos la construcción de cuartos o aéreas limpias diseñadas para cumplir con requerimientos y normas que garanticen un estado prístino de tratamiento de insumos.</p>
                            </div>
                            <div class="foto" id="serv_cuartos">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#cimientos" class="transition">
                    	<div class="w_serv_slide">
							<div class="texto_arriba">
                            	<h1>CIMIENTOS ESPECIALES</h1>
                                <p >Diseñamos, calculamos y ejecutamos cimentaciones especiales de acuerdo a las necesidades de cada industria, planeamos y ejecutamos proyectos de cimentación de prensas y cimentación para silos.</p>
                            </div>
                            <div class="foto" id="serv_cimientos_especiales">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
                <div class="carousel-cell_">
					<a href="servicios.php#instalaciones" class="transition">
                    	<div class="w_serv_slide">
                        	<div class="texto_arriba">
                            	<h1>INSTALACIONES INDUSTRIALES</h1>
                                <p >Planeamos, diseñamos, calculamos distribuimos y pensamos como un grupo especializado para el desarrollo de instalaciones industriales que cumplan con todas las funcionalidades e importancia que requieren los proyectos de nuestros clientes.</p>
                            </div>
                            <div class="foto" id="serv_instalaciones_industriales">
                            	
                            	<div class="overlay"></div>
                            </div>
                        </div>
                    </a>
                </div>
                
			</div>
            
            
        
        <div class="gridContainer clearfix">
            <div class="detalle">
                EXCELENTE INGENIERÍA<br>EN DISEÑO
            </div>   
        </div>
    </div>
    
    <div id="w_ventajas">
    	<div class="gridContainer clearfix">
        	<h1 class="titulo" style=" color: #fff">VENTAJAS<br>COMPETITIVAS</h1><br><br>
            
            <div class="uno_uno">
                <div class="img_ventajas_l" id="v1"></div>
                <div class="txt_ventajas_r">
                    <h1>EXPERIENCIA</h1>
                    <p>Con un grupo especializado con más de 30 años de trabajo, tenemos la capacidad de desarrollar cualquier proyecto de construcción mediante la generación de Paquetes Completos de Obra.</p>
                </div>
                <div class="linea_ch"></div>
                <div class="cleare"></div>
            </div>
            
            <div class="uno_uno">
            <div class="img_ventajas_l" id="v5"></div>
            	<div class="txt_ventajas_l">
                    <h1>CONFIABILIDAD</h1>
                    <p>Trabajamos con y para nuestros clientes. Estamos comprometidos con cada parte del proceso para poder garantizar un servicio eficiente y de gran calidad.</p>
                </div>
                <div class="img_ventajas_l" id="v2"></div>
                <div class="linea_ch"></div>
                <div class="cleare"></div>
            </div>
            
            <div class="uno_uno">
                <div class="img_ventajas_l" id="v3"></div>
                <div class="txt_ventajas_r">
                    <h1>SOLIDEZ</h1>
                    <p>Edificamos plantas industriales, bodegas y edificios comerciales, mediante procesos integrales que cuidan cada aspecto del proyecto, permitiéndonos ofrecer confianza y seguridad.</p>
                </div>
                <div class="linea_ch"></div>
                <div class="cleare"></div>
            </div>
            
            <div class="uno_uno">
            	<div class="img_ventajas_l" id="v6"></div>
            	<div class="txt_ventajas_l">
                    <h1>SINERGIA</h1>
                    <p>Desarrollamos proyectos en colaboración constante y con objetivos claros para lograr que la  la ejecución de cada proyecto sea estético, funcional y con un fuerte sentido de ingeniería en diseño.</p>
                </div>
                <div class="img_ventajas_l" id="v4"></div>
                <div class="linea_ch"></div>
                <div class="cleare"></div>
            </div>
            
            <div class="cleare"></div>
        </div>
    </div>
    

    <div id="w_clientes">
    	
        <div class="wrapcli"> 
        <h1 class="titulo" style="text-align: center">CLIENTES</h1><br>
        <div id="reslog" style="display:flex">
            <div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/01_TRUPER.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/2-advance.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/3-fitesa.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/4-irritec.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/5-narmco.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/ctesnucitec.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/6-ronalgroup.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/8-aceway.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/8-asimex.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/7-grapuc.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/10-mapei.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/11-kirchoff.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/12-mexicana.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/13-ricsa.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/rocktenn.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/sika_-.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/yakult.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/15-caneels.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/14-laQuinta.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/32-cooperstandard.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/17-facet.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/18-plasti.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/19-revlon.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/20-bandag.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/21-rubbermind.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/22-elica.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/22alpina.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/23-stempco.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/24-moelo.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/24ppg.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/25-inter.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/26-condumex.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/27-inland.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/28-interceramic.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/29-shering.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/crinamex.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/c-durango.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/30-braun.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/31-carrier.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/32-playtex.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/inamex.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/quinro.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/32-alcan.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/11clevete.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/valuadata.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/1narmx.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/qpomps.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/itpacero.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/yamada.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/alpura.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/lucta.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/brog.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/fanasa.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/motsa.jpg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/wabtec.svg" width="170px"></div></div><div style="height:100px; padding: 20px; width:28%"><div class="w_serv_slide-" style="display:flex;align-items: center;justify-content: center;"><img src="images/vidrio.svg" width="170px"></div></div>	
        </div>
        <div class="cleare"></div>
        </div>
    </div>

	<div id="w_contacto">
    	<div id="w_maps">
    	    <div id="google"> <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14941.432457721949!2d-100.361186!3d20.573428!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbce086aa08210637!2sConstructora+Insur!5e0!3m2!1sen!2smx!4v1486599037780" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe> </div>
        </div>
       
    	<div id="form">
            <br><br>
        	<h1 class="titulo" style=" padding: 20px 0 0 0">CONTACTO</h1>
            <p id="fullpx">
            <span style=" color: #000">Querétaro</span><br>
            Av. Ing. Armando Birlain No. 2001, Piso 2-A<br>
            Corporativo 2 Central Park, CP. 76090, Col Centro Sur<br>
            Santiago de Querétaro, Qro.<br>
            Tel. (442) 215 3019<br><br>

            <span style=" color: #000">San Luis Potosí</span><br>
            Av. Cordillera de los Himalaya No. 1018 <br>
            Frac. Lomas 4ta Sección CP. 78216<br>
            San Luis Potosí, SLP.<br>
            Tel (444) 246 5250<br><br>
            <a href="mailto:info@constructorainsur.com" style=" color: #000">info@constructorainsur.com</a></p>
            <div id="formm">
                        
            <form action="index.php#w_contacto" method="post" onSubmit="return validar_contacto()">
                <input type="hidden" name="bandera" value="1">
            	<input type="text" class="input" name="nombre" id="nombre" placeholder="Nombre">
                <input type="text" class="input" name="tel" id="tel" placeholder="Tel">
                <input type="email" class="input" name="email" id="email" placeholder="Email">
                <textarea class="input" name="comentario" id="comentario" placeholder="Mensaje" style=" height: 100px;"></textarea>
                <div class="recaptcha-wrap2">                   
                	<div class="g-recaptcha" data-theme="dark" data-sitekey="6LdAgSAUAAAAABx5tHLNEmrGw57BIqRbj7DyXk7X"></div>
				</div>
                <input type="submit" class="input mandar" value="Enviar" style=" background: #1b2b56; color: #fff;">
            </form>
            
                        </div>
        </div>
        <div class="cleare"></div>
    </div>
    
    <div id="w_footer" style="letter-spacing:1px">
    	<div class="gridContainer clearfix">
        	<div id="logo_ft"> <img src="images/logo_ft.png"> <p>®2020, DERECHOS RESERVADOS</p> </div>
            <div id="redes_ft"> <p>Tel. (442) 215 3019 /</p>
            <a href="mailto:info@constructorainsur.com" style=" color: #fff">info@constructorainsur.com</a>
            <a id="fbfull" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fbfull" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fbfull" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fbfull" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
            </div>
            <a id="fb" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fb" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fb" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fb" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
        	<div class="cleare"></div>
        </div>
    </div>

<!--fin de responsive-->
</div>
<div class="quitar--caca">

    <link rel="stylesheet" href="css/flickity.css" media="screen">
    <script src="js/flickity.pkgd.js"></script>
    <script src="js/flickity-docs.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.main-carousel').flickity({
                // options
                cellAlign: 'left',
                groupCells: 3,
                imagesLoaded: true,
                pageDots: false,
                autoPlay: 6000,
            });
        });
    </script>
</div>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
		(function () {
		var options = {
		whatsapp: "+524423150697", // WhatsApp number
		call_to_action: "Escríbenos", // Call to action
		position: "right", // Position may be 'right' or 'left'
		};
		var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
		var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
		s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
		var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
		})();
	</script>
	<!-- /WhatsHelp.io widget --> 
</body>
</html>
