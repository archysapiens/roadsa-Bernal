<!doctype html>
<!--[if lt IE 7]> <html class="ie6 oldie"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 oldie"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 oldie"> <![endif]-->
<!--[if gt IE 8]><!-->
<html>
<!--<![endif]-->
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>INSUR - constructora</title><link rel="shortcut icon" href="images/favicon.png"><meta name="description" content="Especialistas en las construcción de Naves y Obras Industriales" /><meta name="keywords" content="Construcción  de naves industriales, Construcción  de naves industriales Bajio, Construcción de naves industriales mexico, Construcción de naves industriales queretaro, Construcción de naves industriales san Luis potosi, Construcción industrial, Construcción industrial bajio, Construcción industrial mexico, Construcción industrial Queretaro, Construcción industrial San Luis potosi, Naves industriales, Naves industriales bajio, Naves industriales  Mexico, Naves industriales Queretaro, Naves industriales  San Luis potosi, Construcción obra civil, Construcción estructura metálica, Arquitectura industrial, Construcción de bodegas, Construcción de almacenes, Construcción de plantas de produccion, Construcción de cuartos limpios, Construcción alimenticia, Construcción farmacéutica, Construcción cimentaciones especiales"/><link href="css/boilerplate.css" rel="stylesheet" type="text/css" media="all"><link href="css/estilos.min.css" rel="stylesheet" type="text/css" media="all"><link href="https://fonts.googleapis.com/css?family=Roboto:400,900" rel="stylesheet">

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script async src="js/respond.min.js"></script><link href="css/owl.carousel.css" rel="stylesheet"><link href="css/owl.theme.css" rel="stylesheet"><link href="css/owl.transitions.css" rel="stylesheet"><link async href="assets/js/google-code-prettify/prettify.css" rel="stylesheet">  <script src="assets/js/jquery-1.9.1.min.js"></script> <script src="js/owl.carousel.js"></script><style>#owl-demo .item img, #owl-demo_interna .item img, #owl-demo2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){var a=$("#owl-demo");a.owlCarousel({navigation:!1,singleItem:!0,transitionStyle:"fade",autoPlay:7e3}),$("#transitionType").change(function(){var t=$(this).val();a.data("owlCarousel").transitionTypes(t),a.trigger("owl.next")})});</script><script src='https://www.google.com/recaptcha/api.js'></script>	<style>#owl-demo_2 .item img{display: block;width: 100%;height: auto;}</style><script>$(document).ready(function(){$("#owl-demo_2").owlCarousel({navigation:!1,slideSpeed:300,singleItem:!0,autoPlay:!0,lazyLoad:!0})});</script><script type="text/javascript">$(document).on("scroll",function(){$(document).scrollTop()>360?($("#submenu").addClass("fijo"),$("#w_gale_proy").addClass("espacio")):($("#submenu").removeClass("fijo"),$("#w_gale_proy").removeClass("espacio"))}),$(document).ready(function(){$("#cerrar").click(function(){$("#example2_pop").hasClass("quitar")?($("#example2_pop").removeClass("quitar"),$("#cerrar").removeClass("girar")):($("#example2_pop").addClass("quitar"),$("#example2_pop_").addClass("quitar"),$("#cerrar").addClass("girar"))})}),$(document).ready(function(){$("#chat").click(function(){$("#example2_pop").hasClass("ver")?$("#example2_pop").removeClass("ver"):($("#example2_pop").addClass("ver"),$("#example2_pop_").addClass("ver"))})});</script><script>$(function(t){t("#submenu a").click(function(){var n=t(this).attr("href"),a=t(n).offset().top;return t("html:not(:animated),body:not(:animated)").animate({scrollTop:a},400),!1})});</script><script>function validar_contacto(){var e=document.getElementById("nombre").value,t=document.getElementById("email").value,n=document.getElementById("comentario").value;return 0==e.length?(alert("Ingresa tu nombre"),nombre.focus(),!1):0==t.length?(alert("Ingresa un correo electrónico"),email.focus(),!1):0==n.length?(alert("Dejanos tus comentarios"),comentario.focus(),!1):void 0}</script><script async src="https://www.googletagmanager.com/gtag/js?id=UA-45144045-1"></script>
  
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
 
  gtag('config', 'UA-45144045-1');
</script>
</head>
<body>
    
    <ul class="navigation">
  <li> <a href="index.php" class="transition" >HOME</a> </li>
                    <li> <a href="conocenos.php" class="transition" >CONÓCENOS</a> </li>
                    <li> <a href="servicios.php" class="activo transition" >SERVICIOS</a> </li>
                    <li> <a href="proyectos.php" class="transition" >PROYECTOS</a> </li>
                    <li> <a href="clientes.php" class="transition" >CLIENTES</a> </li>
                    <li> <a href="contacto.php" class="transition" >CONTACTO</a> </li>
                    <li> <li> <a href="ing/servicios.php">ENG</a> </li> </li>

  <li><a href="mailto:info@constructorainsur.com">info@constructorainsur.com<br />(442) 215 3019</a></li>
</ul>
<input type="checkbox" id="nav-trigger" class="nav-trigger" />
<label for="nav-trigger"></label>
    <div class="site-wrap">
    <div id="logo_ip"><img class="logo" src="images/logo_menu.jpg" width="48%"/></div>

<div id="w_menu">
        <div class="gridContainer clearfix">
        	<div id="logo_menu"> <a href="index.php"><img src="images/logo_menu.jpg"></a> </div>
            <div id="menu">
            	<ul>
                	<li> <a href="index.php" class="transition" >home</a> </li>
                    <li> <a href="conocenos.php" class="transition" >conócenos</a> </li>
                    <li> <a href="servicios.php" class="activo transition" >servicios</a> </li>
                    <li> <a href="proyectos.php" class="transition" >proyectos</a> </li>
                    <li> <a href="clientes.php" class="transition" >clientes</a> </li>
                    <li> <a href="contacto.php" class="transition" >contacto</a> </li>
                    
                    <li> <a href="ing/servicios.php"><img src="images/idioma.png"> ENG</a> </li>                    
                </ul>
            </div>
            <div class="cleare"></div>
        
        </div>
    </div>
        
    <div id="top">
    	        <div id="redes"> 
        	<div id="face" class="redes_flotante"> <a href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"> <img src="images/face.png"></a> </div>
            <div id="idioma" class="redes_flotante"> <a href="#"><img src="images/idioma.png"> ENG</a></div>
        	<div class="cleare"></div>
        </div>        
        <div id="slide_internas" style=" background: url(images/slide_serv.jpg) center / cover">
        	<div class="caption">ESPECIALISTAS<br><!--<hr style=" width: 30px; text-align: center">--><span>EN LA CONSTRUCCIÓN DE NAVES Y OBRAS INDUSTRIALES</span></div>
        </div>
    </div>
    
    <div id="submenu">
    	<div class="gridContainer clearfix">
        	<ul>
            	<li> <a href="#estudios">ESTUDIOS PRELIMINARES</a></li>
                <li> <a href="#arquitectonicos">PROYECTOS ARQUITECTÓNICOS</a></li>
                <li> <a href="#construccion">CONSTRUCCIÓN DE OBRA CIVIL</a></li>
                <li> <a href="#terracerias">TERRACERÍAS</a></li>
                <li> <a href="#edificacion">EDIFICACIÓN</a></li>
                <li> <a href="#estructuras">ESTRUCTURAS METÁLICAS Y CUBIERTAS</a></li>
                <li> <a href="#cuartos">CUARTOS LIMPIOS</a></li>
                <li> <a href="#cimientos">CIMIENTOS ESPECIALES</a></li>
                <li> <a href="#instalaciones">INSTALACIONES INDUSTRIALES</a></li>
            </ul>
        </div>
    </div>
    
    <div id="w_servicios">
		<h1 class="titulo" style=" text-align: center;">SERVICIOS</h1><br><br>
        
        <div class="bg_primero">
        	<div class="ancla" id="estudios"></div>
        	<div class="wrapserv">    
            	<div class="foto_serv_l" style=" background: url(images/serv1.png) no-repeat center / cover">
                	<div class="numero">01</div>
                </div>
                <div class="txt_servicios6">
                	<h1>ESTUDIOS PRELIMINARES</h1>
                    <p class="flotante" style="text-align: justify;">Enfocados en la realización de proyectos integrales, en Constructora Insur ofrecemos una amplia gama de procesos para el desarrollo de todo proyecto y durante la construcción de toda obra, nuestra experiencia y precisión, nos permite realizar trabajos de planimetría y altimetría, así como diversos estudios preliminares propios de cada obra, que nos permiten llevar a cabo:<br><br>
                    
                    <span class="otrocolor">
                    - Obtención de poligonales.<br>
                    - Cálculo de superficies. <br>
                    - Nivelación y configuración de predios.<br>
                    - Obtención de niveles de desplante.<br>
                    - Obtención de volúmenes de terracerías.<br>
                    - Diseño de drenajes.<br>
                    - Diseño de vialidades y patios, etc.
                    </span>
                    </p>

                    <p id="ull" style="text-align: justify;">Estos procedimientos componen la gama de aplicaciones al inicio de cualquier trabajo y son de vital importancia en constructora INSUR realizamos con profesionalismo la ingeniería de suelos, que por medio de sondeos y pozos a cielo abierto nos permiten obtener la estratigrafía y propiedades del suelo, con la finalidad de generar condiciones óptimas de viabilidad, confianza y planeación para el diseño y cálculo de cualquier tipo de cimentación, garantizando construcciones confiables y seguras.</p>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_segundo">
        <div class="ancla" id="arquitectonicos"></div>
        	<div class="wrapserv">  
            <div class="foto_serv_2" id="serres" style=" background: url(images/RONAL-7.jpg) no-repeat center / cover">
                	<div class="numero_dos">02</div>
                </div>  
                <div class="txt_servicios">
                	<h1>PROYECTOS ARQUITECTÓNICOS</h1>
                    <p class="flotante" style="text-align: justify;">En Insur cada proyecto representa un compromiso profundo con la calidad, para lograr esto conjugamos elementos clave de nuestro equipo para trabajar con nuestros clientes y poder desarrollar así proyectos de calidad total a la altura de las expectativas y que sean capaces de satisfacer todas sus necesidades actuales y futuras mediante: </p>
                    <p class="flotante" style="text-align: justify;">
                    	 <span class="otrocolor">
					- Construcciones Funcionales.<br>- Optimización de Áreas. <br>- Obras Estéticas.<br>- Preparación de Expansiones.<br>- Sistemas Constructivos Actualizados.<br>- Excelente Selección de Acabados.<br>- Instalaciones Adecuadas.
                    </span>
                    </p>
				</div>
                <div class="foto_serv_2" style=" background: url(images/RONAL-7.jpg) no-repeat center / cover">
                	<div class="numero_dos">02</div>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_primero">
        <div class="ancla" id="construccion"></div>
        	<div class="wrapserv">    
            	<div class="foto_serv_l" style=" background: url(images/serv3.png) no-repeat center / cover">
                	<div class="numero">03</div>
                </div>
                <div class="txt_servicios6">
                	<h1>CONSTRUCCIÓN DE OBRA CIVIL</h1>
                    <p style="text-align: justify;" class="flotante">Para Insur no hay nada más importante que nuestros clientes y sus proyectos, por ello realizamos con eficacia, cuidado en el rendimiento económico y profesionalismo la construcción de Accesos, Vialidades, Estacionamientos y Patios de Maniobras, así como todo tipo de Urbanizaciones. </p>
                    <p style="text-align: justify;" id="ull">En la construcción de Pisos Industriales hacemos uso de herramientas vanguardistas que nos permitan realizar Cálculos y Diseños específicos para cada obra, empleando concretos y aceros de alta resistencia, aditivos de alto desempeño, fibras sintéticas, endurecedores, selladores, membranas de curado, para lograr nuestros objetivos utilizamos equipos láser, reglas vibradoras, allanadoras mecánicas y demás equipo y herramientas actualizadas para este tipo de trabajos.</p>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_segundo">
        <div class="ancla" id="terracerias"></div>
        	<div class="wrapserv"> 
            <div class="foto_serv_2" id="serres" style=" background: url(images/serv4.png) no-repeat center / cover">
                	<div class="numero_dos">04</div>
                </div>   
                <div class="txt_servicios">
                	<h1>TERRACERÍAS</h1>
                    <p style="text-align: justify;" class="flotante">Para cualquier desarrollo y construcción, el manejo de suelos representa una piedra angular para acceso, soporte y planeación de la obra, ofrecemos soluciones en Cortes, Rellenos, Nivelaciones y Mejoramiento de Suelos.  </p>
                    <p style="text-align: justify;" class="flotante">Todos son realizados con el mayor factor de seguridad, apoyándolos con Pruebas de Laboratorio para verificar Pesos Volumétricos, Contenido de Humedad y Porcentajes de Compactación requeridos, según el Diseño y Cálculos previamente establecidos.</p>
				</div>
                <div class="foto_serv_2" style=" background: url(images/serv4.png) no-repeat center / cover">
                	<div class="numero_dos">04</div>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_primero">
        <div class="ancla" id="edificacion"></div>
        	<div class="wrapserv">    
            	<div class="foto_serv_l" style=" background: url(images/serv5.png) no-repeat center / cover">
                	<div class="numero">05</div>
                </div>
                <div class="txt_servicios6">
                	<h1>EDIFICACIÓN</h1>
                    <p style="text-align: justify;" class="flotante">En CONSTRUCTORA INSUR queremos convertir grandes ideas en grandes construcciones, por ello establecemos y ejecutamos modelos y planes de trabajo estructurado para lograr levantar cualquier edificación. Contamos con la asesoría técnica y profesional para la realización del Proyecto y Construcción de la Edificación que su empresa requiera, tales como: 
                    <br><br>
                    <span class="otrocolor">
                    - Edificaciones para Oficinas.<br>
                    - Edificios Comerciales.<br>
                    - Edificios para Baños.<br>
                    - Comedores y Servicios.<br>
                    - Cuartos Tipo Industrial.<br>
                    - Casetas de Vigilancia, etc.
                    </span>
                    </p>
                    <p style="text-align: justify;" id="ull">Queremos optimizar los espacios para todo el personal, creemos sobretodo en la importancia de contar con edificios de oficinas Funcionales y Estéticas para mantener un ambiente de trabajo motivador y propicio para las actividades que se realizan gracias al desarrollo de instalaciones bien Proyectadas y Confortables.</p>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_segundo">
        <div class="ancla" id="estructuras"></div>
        	<div class="wrapserv"> 
            <div class="foto_serv_2" id="serres" style=" background: url(images/serv6.png) no-repeat center / cover">
                	<div class="numero_dos">06</div>
                </div>   
                <div class="txt_servicios">
                	<h1>ESTRUCTURAS METÁLICAS Y CUBIERTAS</h1>
                    <p style="text-align: justify;" class="flotante">Con tres décadas de experiencia, en Insur estamos orgullosos de poder contribuir en con nuestros clientes desde el primer momento, te ofrecemos Diseño, Fabricación, Transporte y Montaje de estructuras metálicas a base de Marcos Rígidos de sección variable, los cuales poseen una gran versatilidad para ser empleados en Construcciones Industriales, Bodegas y Edificios Comerciales, cubriendo Grandes Claros con gran Rapidez, Economía y proporcionando una Apariencia Inmejorable.</p>
                    <p style="text-align: justify;" class="flotante">Sistemas Estructurales Básicos:<br><br>
                    1.- · Marco rígido de un solo claro.<br>
                    · Techumbre con gran inclinación 33%.<br>
                    · Para condiciones especiales.
                    <br><br>
                    
                    2 .- · Marco rígido de un solo claro.<br>
                    · Techumbre con poca inclinación 8.33%.<br>
                    · Para grandes claros sin columnas intermedias.
                    <br><br>
                    
                    3.- · Marco rígido múltiple.<br>
                    · Con varios claros.<br>
                    · Para edificios anchos.<br>
                    · Inclinación de 8.33%.</p>
				</div>
                <div class="foto_serv_2" style=" background: url(images/serv6.png) no-repeat center / cover">
                	<div class="numero_dos">06</div>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_primero">
        <div class="ancla" id="cuartos"></div>
        	<div class="wrapserv">    
            	<div class="foto_serv_l" style=" background: url(images/serv7.png) no-repeat center / cover">
                	<div class="numero">07</div>
                </div>
                <div class="txt_servicios6">
                	<h1>CUARTOS LIMPIOS</h1>
                    <p style="text-align: justify;" class="flotante">Gracias a nuestra experiencia y conocimiento de nuestros clientes, en INSUR, ofrecemos el servicio especializado para cada tipo de industria con la finalidad de satisfacer sus necesidades y resolver cualquier problema, para el ramo alimenticio, farmacéutico y laboratorios ofrecemos la  construcción de cuartos o aéreas limpias diseñadas para cumplir con requerimientos y normas que garanticen un estado prístino de tratamiento de insumos y materiales. </p>
                    <p style="text-align: justify;" id="ull">Complementamos éste servicio con las opciones de Sistemas HVAC, Sistemas de Purificación de Agua, Instalación de Aire Lavado, Cámaras Refrigeradas, entre otros.</p>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_segundo">
        <div class="ancla" id="cimientos"></div>
        	<div class="wrapserv">
            <div class="foto_serv_2" id="serres" style=" background: url(images/ffff.jpg) no-repeat center / cover">
                	<div class="numero_dos">08</div>
                </div>    
                <div class="txt_servicios">
                	<h1>CIMIENTOS ESPECIALES</h1>
                    <p style="text-align: justify;" class="flotante">Diseñamos, calculamos y ejecutamos cimentaciones especiales de acuerdo a las necesidades de cada industria, planeamos y ejecutamos proyectos de cimentación de prensas y cimentación para silos o equipos</p>
                    <p style="text-align: justify;" class="flotante"> de alto tonelaje ya sean estáticos ó dinámicos, siguiendo los más altos estándares de seguridad e implementando ingeniería de vanguardia.</p>
				</div>
                <div class="foto_serv_2" style=" background: url(images/ffff.jpg) no-repeat center / cover">
                	<div class="numero_dos">08</div>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
        <div class="bg_primero">
        	<div class="ancla" id="instalaciones"></div>
        	<div class="wrapserv">    
            	<div class="foto_serv_l" style=" background: url(images/serv9.png) no-repeat center / cover">
                	<div class="numero">09</div>
                </div>
                <div class="txt_servicios6">
                	<h1>INSTALACIONES INDUSTRIALES</h1>
                    <p style="text-align: justify;" class="flotante">Planeamos, diseñamos, calculamos distribuimos y pensamos como un grupo especializado para el desarrollo de instalaciones industriales que cumplan con todas las funcionalidades e importancia que requieren los proyectos de nuestros clientes. Realizamos instalaciones de los siguientes tipos:</p>
                    <p id="ull">
                    	<span class="otrocolor">
                        - Aire acondicionado.<br>
                        - Instalaciones eléctricas.<br>
                        - Sistema de protección contra incendios.<br>
                        - Instalaciones mecánicas.<br>
                        - Instalaciones de vapor, neumáticas, étc.
                        </span>
                    </p>
                </div>
                <div class="cleare"></div>
        	</div>
        </div>
        
    </div>
    
    <div id="w_footer" style="letter-spacing:1px">
    	<div class="gridContainer clearfix">
        	<div id="logo_ft"> <img src="images/logo_ft.png"> <p>®2020, DERECHOS RESERVADOS</p> </div>
            <div id="redes_ft"> <p>Tel. (442) 215 3019 /</p>
            <a href="mailto:info@constructorainsur.com" style=" color: #fff">info@constructorainsur.com</a>
            <a id="fbfull" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fbfull" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fbfull" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fbfull" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
            </div>
            <a id="fb" href="https://www.facebook.com/ConstructoraInsur/?fref=ts" target="_blank"><img src="images/face_ft.png"></a>
            <a id="fb" href="https://twitter.com/constructoinsur?lang=es" target="_blank"><img src="images/twitter_ft.png"></a>
            <a id="fb" href="https://mx.linkedin.com/company/constructora-insur" target="_blank"><img src="images/linked_ft.png"></a>
            <a id="fb" href="https://www.instagram.com/constructorainsur/" target="_blank"><img src="images/instagram_ft.png"></a>
        	<div class="cleare"></div>
        </div>
    </div>

<!--fin de responsive-->
</div>
<div class="quitar--caca">

    <link rel="stylesheet" href="css/flickity.css" media="screen">
    <script src="js/flickity.pkgd.js"></script>
    <script src="js/flickity-docs.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.main-carousel').flickity({
                // options
                cellAlign: 'left',
                groupCells: 3,
                imagesLoaded: true,
                pageDots: false,
                autoPlay: 6000,
            });
        });
    </script>
</div>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
		(function () {
		var options = {
		whatsapp: "+524423150697", // WhatsApp number
		call_to_action: "Escríbenos", // Call to action
		position: "right", // Position may be 'right' or 'left'
		};
		var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
		var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
		s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
		var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
		})();
	</script>
	<!-- /WhatsHelp.io widget --> 
</body>
</html>
